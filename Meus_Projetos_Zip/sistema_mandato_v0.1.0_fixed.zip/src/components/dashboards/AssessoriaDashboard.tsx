import LogoutButton from "@/components/LogoutButton";
import { getAdminDashboardStats } from "@/lib/supabase/api";
import AprovalQueue from "../assessoria/AprovalQueue";

interface AssessoriaDashboardProps {
  user: any;
}

const StatCard = ({ label, value }: { label: string, value: number | null | undefined }) => (
  <div className="p-4 bg-surface2 rounded-lg text-center">
    <p className="text-3xl font-display text-accent">{value ?? '_'}</p>
    <p className="text-xs text-muted uppercase tracking-wider mt-1">{label}</p>
  </div>
);

export default async function AssessoriaDashboard({ user }: AssessoriaDashboardProps) {
  
  const { data: stats, error } = await getAdminDashboardStats();
  
  return (
    <div className="w-full max-w-4xl mx-auto animate-fadeIn">
      <div className="p-6 rounded-lg bg-surface mb-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-bold uppercase tracking-wider text-purple">
              Assessoria · Admin
            </p>
            <h1 className="text-2xl font-display text-text mt-1">
              Painel de Gestão
            </h1>
          </div>
          <LogoutButton />
        </div>
      </div>
      
      <div className="p-4 space-y-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Municípios" value={stats?.municipios} />
          <StatCard label="Contatos Aprovados" value={stats?.contatos} />
          <StatCard label="Emendas" value={stats?.emendas} />
          <StatCard label="Pendências Abertas" value={stats?.pendencias} />
        </div>

        {error && <p className="text-red text-center">Erro ao carregar estatísticas: {error.message}</p>}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Coluna da Esquerda: Cidades e Aprovações */}
          <div className="md:col-span-1 space-y-6">
            {/* Lista de Cidades */}
            <div>
              <p className="text-sm font-bold uppercase tracking-wider text-muted mb-2">Municípios</p>
              <div className="p-4 bg-surface2 rounded-lg">
                <p className="text-center text-muted">Lista de municípios aqui.</p>
              </div>
            </div>
            {/* Fila de Aprovação */}
            <div>
              <p className="text-sm font-bold uppercase tracking-wider text-muted mb-2">Contatos para Aprovação</p>
              <div className="p-4 bg-surface2 rounded-lg">
                <AprovalQueue />
              </div>
            </div>
          </div>

          {/* Coluna da Direita: Painel de Edição */}
          <div className="md:col-span-2">
            <p className="text-sm font-bold uppercase tracking-wider text-muted mb-2">Editor</p>
            <div className="p-4 bg-surface2 rounded-lg min-h-[400px]">
              <p className="text-center text-muted">Selecione um item para editar.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
