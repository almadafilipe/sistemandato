'use server';

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

async function updateContactStatus(contactId: string, status: 'aprovado' | 'rejeitado') {
  const supabase = await createClient();

  // TODO: Adicionar verificação se o usuário tem a role 'assessoria'

  const { error } = await supabase
    .from('contatos')
    .update({ status: status })
    .eq('id', contactId);

  if (error) {
    console.error(`Erro ao ${status === 'aprovado' ? 'aprovar' : 'rejeitar'} contato:`, error);
    throw new Error('Falha ao atualizar status do contato.');
  }

  revalidatePath('/'); // Revalida o dashboard para atualizar as listas
}

export async function approveContact(contactId: string) {
  return updateContactStatus(contactId, 'aprovado');
}

export async function rejectContact(contactId: string) {
  return updateContactStatus(contactId, 'rejeitado');
}
