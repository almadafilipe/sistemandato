import { headers } from "next/headers";
import { logIn, signUp } from "./actions";

export default async function LoginPage() {
  const searchParams = new URLSearchParams((await headers()).get("x-search-params") || "");
  const message = searchParams.get("message");

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-bg text-text p-4">
      <div className="w-full max-w-sm p-8 space-y-6 bg-surface rounded-lg border border-border">
        <h1 className="text-3xl font-display text-accent text-center">
          Dossiê Municipal
        </h1>
        <p className="text-center text-muted">Acesse a plataforma</p>
        
        <form className="space-y-4">
          <div>
            <label htmlFor="email" className="text-sm font-medium text-muted">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              required
              className="mt-1 block w-full px-3 py-2 bg-bg border border-border2 rounded-md text-sm placeholder-muted focus:outline-none focus:ring-1 focus:ring-accent"
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label htmlFor="password" className="text-sm font-medium text-muted">Senha</label>
            <input
              id="password"
              name="password"
              type="password"
              required
              className="mt-1 block w-full px-3 py-2 bg-bg border border-border2 rounded-md text-sm placeholder-muted focus:outline-none focus:ring-1 focus:ring-accent"
              placeholder="••••••••"
            />
          </div>
          
          <div className="flex flex-col space-y-2">
            <button 
              formAction={logIn}
              className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-semibold text-bg bg-accent hover:bg-accent2 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent2 transition-colors"
            >
              Entrar
            </button>
            <button 
              formAction={signUp}
              className="w-full py-2 px-4 border rounded-md text-sm font-medium text-muted bg-surface hover:border-border2 hover:text-text transition-colors"
            >
              Cadastrar (Dev)
            </button>
          </div>
        </form>

        {message && (
          <p className="text-center text-sm text-red">{message}</p>
        )}
      </div>
    </div>
  );
}
